import { useEffect } from 'react'
import { initScroll, ScrollTrigger } from './lib/scroll'
import Nav from './components/Nav'
import Hero from './components/Hero'
import About from './components/About'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Contact from './components/Contact'

export default function App() {
  useEffect(() => {
    const cleanup = initScroll()
    const refresh = () => ScrollTrigger.refresh()
    window.addEventListener('load', refresh)
    document.fonts?.ready.then(refresh)
    return () => { window.removeEventListener('load', refresh); cleanup() }
  }, [])
  return (
    <>
      <Nav />
      <main><Hero /><About /><Skills /><Projects /><Contact /></main>
    </>
  )
}
