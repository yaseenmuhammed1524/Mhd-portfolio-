import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import { Palette, LayoutDashboard, Code2, MessagesSquare, Users, BrainCircuit, Puzzle } from 'lucide-react'
import { gsap, useGsap } from '../lib/scroll'
import { MaskWords } from './Split'

const skills = [
  { n: 'Graphic Design', I: Palette, d: 'Posters, layouts and brand visuals with strong hierarchy.', lvl: .85, tag: 'Core strength' },
  { n: 'UI/UX Design', I: LayoutDashboard, d: 'Interfaces that are clear first, then beautiful.', lvl: .72, tag: 'Growing fast' },
  { n: 'HTML Basics', I: Code2, d: 'Structuring pages and turning designs into markup.', lvl: .55, tag: 'Building up' },
  { n: 'AI/ML Learning', I: BrainCircuit, d: 'Studying machine learning concepts from the ground up.', lvl: .35, tag: 'Just started' },
  { n: 'Communication', I: MessagesSquare, d: 'Explaining ideas simply and listening to feedback.' },
  { n: 'Teamwork', I: Users, d: 'Sharing work early and building on other people’s ideas.' },
  { n: 'Creative Problem Solving', I: Puzzle, d: 'Finding a simpler route when the obvious one stalls.' },
]

function Card({ s }) {
  const x = useMotionValue(0), y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 220, damping: 22 }), sy = useSpring(y, { stiffness: 220, damping: 22 })
  const rx = useTransform(sy, [-.5, .5], [9, -9]), ry = useTransform(sx, [-.5, .5], [-9, 9])
  const move = (e) => { const r = e.currentTarget.getBoundingClientRect(); x.set((e.clientX - r.left) / r.width - .5); y.set((e.clientY - r.top) / r.height - .5) }
  const reset = () => { x.set(0); y.set(0) }
  return (
    <div className="skill h-full" style={{ perspective: 900 }}>
      <motion.article onPointerMove={move} onPointerLeave={reset} whileHover={{ y: -6 }}
        style={{ rotateX: rx, rotateY: ry, transformStyle: 'preserve-3d' }}
        className="group relative flex h-full min-h-[250px] flex-col justify-between rounded-3xl border p-7 transition-colors duration-500 hairline hover:border-[var(--acc)]">
        <div className="flex items-start justify-between" style={{ transform: 'translateZ(30px)' }}>
          <s.I size={28} strokeWidth={1.4} className="text-[var(--acc)] transition-transform duration-500 group-hover:-rotate-[8deg] group-hover:scale-110" />
          {s.tag && <span className="muted text-xs">{s.tag}</span>}
        </div>
        <div style={{ transform: 'translateZ(40px)' }}>
          <h3 className="display !leading-tight text-2xl">{s.n}</h3>
          <p className="muted mt-2 text-sm leading-relaxed">{s.d}</p>
          {s.lvl && (
            <div className="mt-5 h-[3px] w-full overflow-hidden rounded bg-[var(--line)]" role="img" aria-label={`${s.n}: ${s.tag}`}>
              <div className="bar h-full origin-left rounded bg-[var(--acc)]" style={{ width: `${s.lvl * 100}%` }} />
            </div>
          )}
        </div>
      </motion.article>
    </div>
  )
}

export default function Skills() {
  const root = useRef(null)
  useGsap(root, () => {
    gsap.from('.mword', { yPercent: 110, duration: 1.2, stagger: .08, ease: 'expo.out', scrollTrigger: { trigger: '.s-title', start: 'top 80%' } })
    gsap.from('.skill', { y: 80, opacity: 0, filter: 'blur(12px)', scale: .96, duration: 1.1, stagger: .09, ease: 'expo.out', scrollTrigger: { trigger: '.s-grid', start: 'top 82%' } })
    gsap.from('.bar', { scaleX: 0, duration: 1.6, stagger: .15, ease: 'power3.out', scrollTrigger: { trigger: '.s-grid', start: 'top 60%' } })
  })
  return (
    <section id="skills" ref={root} className="px-5 py-28 md:px-10 md:py-40">
      <h2 className="s-title display max-w-4xl text-[clamp(2.6rem,8vw,7rem)]"><MaskWords text="What I bring to a project" /></h2>
      <div className="s-grid mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {skills.map((s, i) => <div key={s.n} className={i === 6 ? 'sm:col-span-2' : ''}><Card s={s} /></div>)}
      </div>
    </section>
  )
}
