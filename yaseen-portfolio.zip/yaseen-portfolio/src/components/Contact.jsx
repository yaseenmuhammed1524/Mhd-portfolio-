import { useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Mail, Phone, Linkedin, Instagram, Send, Copy, Check, ArrowUpRight } from 'lucide-react'
import { gsap, useGsap } from '../lib/scroll'
import { MaskWords } from './Split'

const EMAIL = 'muhammedyaseen98967@gmail.com'
const LI = 'https://linkedin.com/in/muhammed-yaseen-7583823a3'
const IG = 'https://instagram.com/mr_.yaseen__'
const rows = [[Mail, EMAIL, `mailto:${EMAIL}`], [Phone, '+91 9778724877', 'tel:+919778724877'], [Linkedin, 'linkedin.com/in/muhammed-yaseen-7583823a3', LI], [Instagram, '@mr_.yaseen__', IG]]
const socials = [[Linkedin, 'LinkedIn', LI], [Instagram, 'Instagram', IG], [Mail, 'Email', `mailto:${EMAIL}`], [Phone, 'Phone', 'tel:+919778724877']]
const field = 'w-full border-b bg-transparent py-4 text-lg outline-none transition-colors hairline placeholder:text-[var(--mut)] focus:border-[var(--acc)]'
const ext = (h) => h.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {}

export default function Contact() {
  const root = useRef(null)
  const [f, setF] = useState({ name: '', email: '', message: '' })
  const [err, setErr] = useState({})
  const [status, setStatus] = useState(null)
  const [copied, setCopied] = useState(false)

  useGsap(root, () => {
    gsap.from('.mword', { yPercent: 110, duration: 1.2, stagger: .07, ease: 'expo.out', scrollTrigger: { trigger: '.c-title', start: 'top 80%' } })
    gsap.from('.c-in', { y: 50, opacity: 0, filter: 'blur(8px)', stagger: .1, duration: 1, ease: 'expo.out', scrollTrigger: { trigger: '.c-grid', start: 'top 80%' } })
  })

  const on = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setErr({ ...err, [k]: '' }); setStatus(null) }
  const body = () => `${f.message}\n\n${f.name} (${f.email})`
  const submit = (e) => {
    e.preventDefault()
    const n = {}
    if (!f.name.trim()) n.name = 'Enter your name.'
    if (!/^\S+@\S+\.\S+$/.test(f.email)) n.email = 'Enter a valid email address.'
    if (f.message.trim().length < 5) n.message = 'Write a short message.'
    setErr(n)
    if (Object.keys(n).length) return
    // No backend is configured, so the message is handed to the visitor's email app rather than pretending it was sent.
    window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent('Portfolio message from ' + f.name)}&body=${encodeURIComponent(body())}`
    setStatus('opened')
  }
  const copy = async () => {
    try { await navigator.clipboard.writeText(`To: ${EMAIL}\n\n${body()}`); setCopied(true); setTimeout(() => setCopied(false), 2000) } catch { setStatus('copyfail') }
  }

  return (
    <section id="contact" ref={root} className="px-5 pt-28 md:px-10 md:pt-40">
      <h2 className="c-title display text-[clamp(2.8rem,10vw,9rem)]"><MaskWords text="Let’s make something together." /></h2>
      <div className="c-grid mt-16 grid gap-16 lg:grid-cols-[1fr_1.1fr]">
        <div className="c-in">
          {rows.map(([I, l, h]) => (
            <a key={l} href={h} {...ext(h)} className="group flex items-center justify-between gap-4 border-b py-5 transition-colors hairline hover:border-[var(--acc)]">
              <span className="flex min-w-0 items-center gap-4"><I size={20} strokeWidth={1.5} className="shrink-0 text-[var(--acc)]" /><span className="truncate text-base md:text-lg">{l}</span></span>
              <ArrowUpRight size={18} className="shrink-0 transition-transform duration-500 group-hover:-translate-y-1 group-hover:translate-x-1" />
            </a>))}
        </div>
        <form onSubmit={submit} noValidate className="c-in space-y-3">
          {[['name', 'Your name', 'text'], ['email', 'Your email', 'email']].map(([k, p, t]) => (
            <div key={k}><label className="sr-only" htmlFor={k}>{p}</label>
              <input id={k} type={t} placeholder={p} value={f[k]} onChange={on(k)} className={field} aria-invalid={!!err[k]} autoComplete={k} />
              {err[k] && <p role="alert" className="pt-2 text-sm text-red-500">{err[k]}</p>}</div>))}
          <div><label className="sr-only" htmlFor="message">Message</label>
            <textarea id="message" rows={4} placeholder="Tell me about your project or idea" value={f.message} onChange={on('message')} className={field + ' resize-none'} aria-invalid={!!err.message} />
            {err.message && <p role="alert" className="pt-2 text-sm text-red-500">{err.message}</p>}</div>
          <div className="flex flex-wrap items-center gap-3 pt-5">
            <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-[var(--acc)] px-7 py-3.5 text-sm font-semibold text-[#161618] transition hover:scale-[1.03]">Open in my email app <Send size={16} /></button>
            <button type="button" onClick={copy} className="hairline inline-flex items-center gap-2 rounded-full border px-6 py-3.5 text-sm font-semibold transition hover:border-[var(--acc)]">{copied ? <Check size={16} /> : <Copy size={16} />}{copied ? 'Copied' : 'Copy message'}</button>
          </div>
          <p className="muted pt-2 text-sm leading-relaxed">This form has no server behind it. The button opens your email app with the message filled in, and nothing is sent until you send it there.</p>
          <AnimatePresence>{status && <motion.p initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} role="status" className="text-sm text-[var(--acc)]">
            {status === 'opened' ? 'Your email app should open now. If it didn’t, use “Copy message” and email me directly.' : 'Couldn’t copy automatically. Please select the text and copy it manually.'}</motion.p>}</AnimatePresence>
        </form>
      </div>

      <footer className="mt-32 border-t py-10 hairline">
        <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-end">
          <p className="display text-[clamp(2rem,6vw,5rem)]">Muhammed Yaseen</p>
          <ul className="flex gap-3">
            {socials.map(([I, l, h]) => (
              <li key={l}><motion.a href={h} {...ext(h)} aria-label={l} whileHover={{ y: -6, rotate: -6 }} whileTap={{ scale: .9 }}
                className="hairline grid h-12 w-12 place-items-center rounded-full border transition-colors hover:border-[var(--acc)] hover:text-[var(--acc)]"><I size={20} strokeWidth={1.5} /></motion.a></li>))}
          </ul>
        </div>
        <p className="muted mt-10 text-sm">© {new Date().getFullYear()} Muhammed Yaseen</p>
      </footer>
    </section>
  )
}
