import { useRef } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { gsap, useGsap } from '../lib/scroll'
import { Portfolio, Travel, Robomy, Posters } from './Visuals'

const projects = [
  { t: 'Personal Digital Portfolio', c: 'Web design and development', d: 'The site you’re on: a cinematic, scroll-driven portfolio designed and built from scratch.', tags: ['React', 'GSAP', 'Tailwind'], V: Portfolio },
  { t: 'TripGoTravel', c: 'Travel website', d: 'A travel website concept focused on easy browsing and a clear path from idea to booking.', tags: ['UI/UX', 'HTML'], V: Travel },
  { t: 'Robomy', c: 'Brand identity', d: 'A brand identity with a friendly robot mark, colour palette and consistent visual language.', tags: ['Logo', 'Branding'], V: Robomy },
  { t: 'Creative Poster Designs', c: 'Graphic design', d: 'A series of poster designs exploring bold shape, colour and typography.', tags: ['Poster', 'Typography'], V: Posters },
]

export default function Projects() {
  const root = useRef(null)
  useGsap(root, () => {
    const mm = gsap.matchMedia()
    mm.add('(min-width:768px) and (prefers-reduced-motion:no-preference)', () => {
      const track = root.current.querySelector('.track')
      const dist = () => track.scrollWidth - innerWidth
      const move = gsap.to(track, { x: () => -dist(), ease: 'none', scrollTrigger: {
        trigger: root.current, pin: true, scrub: .8, start: 'top top', end: () => '+=' + dist(), invalidateOnRefresh: true, anticipatePin: 1,
        onUpdate: (s) => gsap.set('.p-bar', { scaleX: s.progress }) } })
      root.current.querySelectorAll('.panel').forEach((p) => {
        const st = { trigger: p, containerAnimation: move, start: 'left 90%', end: 'right 10%', scrub: true }
        gsap.fromTo(p.querySelector('.visual'), { xPercent: 14, rotate: 5, scale: .9 }, { xPercent: -10, rotate: -3, scale: 1.04, ease: 'none', scrollTrigger: st })
        gsap.fromTo(p.querySelector('.copy'), { opacity: 0, x: 80, filter: 'blur(10px)' }, { opacity: 1, x: 0, filter: 'blur(0px)', ease: 'none', scrollTrigger: { ...st, start: 'left 85%', end: 'left 40%' } })
        gsap.fromTo(p.querySelector('.frame'), { clipPath: 'inset(8% 20% 8% 20% round 40px)' }, { clipPath: 'inset(0% 0% 0% 0% round 28px)', ease: 'none', scrollTrigger: { ...st, start: 'left 95%', end: 'left 30%' } })
      })
    })
    mm.add('(max-width:767px), (prefers-reduced-motion:reduce)', () => {
      gsap.utils.toArray('.panel .frame').forEach((f) =>
        gsap.from(f, { y: 60, opacity: 0, filter: 'blur(10px)', duration: 1, ease: 'expo.out', scrollTrigger: { trigger: f, start: 'top 85%' } }))
    })
    return () => mm.revert()
  })

  return (
    <section id="work" ref={root} className="relative overflow-hidden">
      <div className="px-5 pb-10 pt-24 md:absolute md:left-10 md:top-24 md:z-20 md:p-0 md:mix-blend-difference md:text-white">
        <h2 className="display text-4xl md:text-5xl">Selected projects</h2>
      </div>
      <div className="track">
        {projects.map(({ t, c, d, tags, V }, i) => (
          <article key={t} className="panel group flex items-center px-5 py-6 md:px-10 md:py-0">
            <div className="frame relative grid h-full w-full overflow-hidden rounded-[28px] border border-white/10 bg-ink text-ivory md:mt-14 md:h-[74vh] md:max-h-[760px] md:grid-cols-[.8fr_1.2fr]">
              <div className="copy relative z-10 flex flex-col justify-between gap-10 p-7 md:p-12">
                <span className="text-sm text-white/55">{c} <span className="ml-2 text-violet">{i + 1}/{projects.length}</span></span>
                <div>
                  <h3 className="display text-[clamp(2.4rem,5vw,5rem)] transition-transform duration-700 group-hover:translate-x-2">{t}</h3>
                  <p className="mt-5 max-w-sm leading-relaxed text-white/65">{d}</p>
                  <ul className="mt-6 flex flex-wrap gap-2">{tags.map((g) => <li key={g} className="rounded-full border border-white/15 px-3 py-1 text-xs text-white/70">{g}</li>)}</ul>
                </div>
                <span className="inline-flex items-center gap-2 text-sm text-white/40">Case study coming soon <ArrowUpRight size={16} className="transition-transform duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-violet" /></span>
              </div>
              <div className="relative min-h-[260px] overflow-hidden border-t border-white/10 md:border-l md:border-t-0">
                <div className="absolute inset-0 opacity-50 [background:radial-gradient(circle_at_70%_30%,rgba(167,139,250,.18),transparent_60%)]" />
                <div className="visual absolute inset-[-6%] flex items-center justify-center p-8 transition-transform duration-700 ease-out group-hover:scale-[1.06]"><V /></div>
              </div>
            </div>
          </article>
        ))}
      </div>
      <div className="absolute inset-x-5 bottom-5 z-20 hidden h-px bg-white/15 md:inset-x-10 md:block"><div className="p-bar h-full origin-left scale-x-0 bg-violet" /></div>
    </section>
  )
}
