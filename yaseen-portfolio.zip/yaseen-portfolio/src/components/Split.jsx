const wrap = 'inline-block overflow-hidden align-bottom pb-[.12em] -mb-[.12em]'
export const Chars = ({ text, className = '' }) => (
  <span className={className} aria-label={text}>
    {[...text].map((c, i) => (
      <span key={i} aria-hidden="true" className={wrap}><span className="char inline-block will-change-transform">{c === ' ' ? '\u00A0' : c}</span></span>
    ))}
  </span>
)
export const Words = ({ text, className = '' }) => (
  <span className={className} aria-label={text}>
    {text.split(' ').map((w, i) => (
      <span key={i} aria-hidden="true" className="inline-block whitespace-pre">
        <span className="word inline-block">{w}</span>{' '}
      </span>
    ))}
  </span>
)
export const MaskWords = ({ text, className = '' }) => (
  <span className={className} aria-label={text}>
    {text.split(' ').map((w, i) => (
      <span key={i} aria-hidden="true" className={wrap + ' mr-[.25em]'}><span className="mword inline-block will-change-transform">{w}</span></span>
    ))}
  </span>
)
