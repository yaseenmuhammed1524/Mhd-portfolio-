// Custom-designed placeholder previews. Swap any of these for a real <img> when project images are ready.
const v = '#a78bfa', iv = '#f2efe8'
export const Portfolio = () => (
  <svg viewBox="0 0 480 320" className="h-full w-full" role="img" aria-label="Abstract browser layout">
    <rect x="30" y="30" width="420" height="260" rx="14" fill="#1d1d20" stroke={iv} strokeOpacity=".2" />
    <path d="M30 62h420" stroke={iv} strokeOpacity=".2" />
    {[0, 1, 2].map((i) => <circle key={i} cx={50 + i * 16} cy="46" r="4" fill={i === 0 ? v : iv} fillOpacity={i === 0 ? 1 : .3} />)}
    <text x="56" y="150" fontSize="54" fontWeight="700" fill={iv} fontFamily="Bricolage Grotesque, sans-serif">Hello.</text>
    <rect x="56" y="172" width="150" height="6" rx="3" fill={iv} fillOpacity=".3" /><rect x="56" y="188" width="110" height="6" rx="3" fill={iv} fillOpacity=".18" />
    <rect x="56" y="214" width="84" height="26" rx="13" fill={v} />
    <rect x="290" y="92" width="130" height="170" rx="12" fill={v} fillOpacity=".18" stroke={v} /><rect x="305" y="107" width="100" height="70" rx="8" fill={v} fillOpacity=".5" />
  </svg>)
export const Travel = () => (
  <svg viewBox="0 0 480 320" className="h-full w-full" role="img" aria-label="Abstract mountains and flight path">
    <path d="M0 260 L110 130 L180 210 L270 90 L380 230 L430 170 L480 240 V320 H0Z" fill={v} fillOpacity=".22" />
    <path d="M0 290 L90 200 L170 270 L290 160 L400 280 L480 220 V320 H0Z" fill={v} fillOpacity=".4" />
    <circle cx="370" cy="70" r="28" fill="none" stroke={iv} strokeOpacity=".7" />
    <path d="M40 150 C 140 40, 260 40, 440 120" fill="none" stroke={iv} strokeWidth="1.5" strokeDasharray="4 8" />
    <path d="M434 112l16 8-18 6 2-6z" fill={iv} /><circle cx="40" cy="150" r="6" fill={v} />
  </svg>)
export const Robomy = () => (
  <svg viewBox="0 0 480 320" className="h-full w-full" role="img" aria-label="Abstract robot mark">
    <rect x="150" y="70" width="180" height="170" rx="46" fill="none" stroke={iv} strokeWidth="3" />
    <circle cx="205" cy="148" r="20" fill={v} /><circle cx="275" cy="148" r="20" fill={v} />
    <path d="M205 200h70" stroke={iv} strokeWidth="6" strokeLinecap="round" />
    <path d="M240 70V38" stroke={iv} strokeWidth="3" /><circle cx="240" cy="32" r="8" fill={v} />
    {[v, iv, '#2b2b30', '#5b43c8'].map((c, i) => <rect key={i} x={160 + i * 40} y="270" width="32" height="20" rx="4" fill={c} stroke={iv} strokeOpacity=".2" />)}
  </svg>)
export const Posters = () => (
  <svg viewBox="0 0 480 320" className="h-full w-full" role="img" aria-label="Three overlapping abstract posters">
    <g transform="rotate(-9 130 170)"><rect x="60" y="50" width="130" height="190" rx="6" fill={iv} /><circle cx="125" cy="130" r="38" fill={v} /><rect x="80" y="196" width="90" height="8" fill="#161618" /></g>
    <g transform="rotate(3 240 160)"><rect x="170" y="40" width="140" height="210" rx="6" fill={v} /><path d="M170 190 L310 100 V250 H170Z" fill="#161618" fillOpacity=".5" /><rect x="190" y="62" width="70" height="10" fill={iv} /></g>
    <g transform="rotate(10 360 170)"><rect x="300" y="60" width="120" height="180" rx="6" fill="#26262b" stroke={iv} strokeOpacity=".4" /><rect x="320" y="85" width="80" height="80" fill="none" stroke={v} strokeWidth="4" /><rect x="320" y="190" width="60" height="8" fill={iv} /></g>
  </svg>)
