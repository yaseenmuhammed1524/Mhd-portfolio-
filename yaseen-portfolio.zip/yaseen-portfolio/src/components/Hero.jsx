import { useEffect, useRef } from 'react'
import { ArrowDown } from 'lucide-react'
import { gsap, useGsap, scrollToId, reduced } from '../lib/scroll'
import { Chars } from './Split'

const chips = [['BCA', '6%', '20%', 40], ['AI/ML', '74%', '4%', 70], ['UI/UX', '82%', '72%', 30], ['Design', '2%', '76%', 55]]

export default function Hero() {
  const root = useRef(null), rig = useRef(null)

  useGsap(root, () => {
    const tl = gsap.timeline({ defaults: { ease: 'expo.out' }, delay: .15 })
    tl.from('.char', { yPercent: 115, rotate: 6, duration: 1.3, stagger: .035 })
      .from('.h-sub', { y: 24, opacity: 0, filter: 'blur(8px)', duration: 1 }, '-=.9')
      .from('.h-intro', { y: 24, opacity: 0, filter: 'blur(8px)', duration: 1 }, '-=.8')
      .from('.h-btn', { y: 20, opacity: 0, stagger: .1, duration: .9 }, '-=.8')
      .from('.stage', { scale: .7, opacity: 0, duration: 1.8 }, 0.2)
      .from('.chip', { scale: 0, opacity: 0, stagger: .1, duration: .8, ease: 'back.out(2)' }, '-=1')
    gsap.to(rig.current, { rotateY: 360, duration: 48, ease: 'none', repeat: -1 })
    gsap.to('.layer', { rotate: '+=8', yoyo: true, repeat: -1, duration: 5, ease: 'sine.inOut', stagger: .5 })
    const sc = { trigger: root.current, start: 'top top', end: 'bottom top', scrub: true }
    gsap.to('.h-content', { yPercent: -18, opacity: 0, scrollTrigger: sc })
    gsap.to('.stage-wrap', { yPercent: 25, scale: 1.25, scrollTrigger: sc })
    gsap.to('.h-cue', { opacity: 0, scrollTrigger: { ...sc, end: '+=200' } })
  })

  useEffect(() => {
    if (reduced() || !window.matchMedia('(pointer:fine)').matches) return
    const el = root.current
    const move = (e) => {
      const nx = e.clientX / innerWidth - .5, ny = e.clientY / innerHeight - .5
      gsap.to('.stage-tilt', { rotateY: nx * 26, rotateX: -ny * 22, duration: 1.2, ease: 'power3.out', overwrite: 'auto' })
      el.querySelectorAll('[data-depth]').forEach((n) =>
        gsap.to(n, { x: nx * n.dataset.depth, y: ny * n.dataset.depth, duration: 1.2, ease: 'power3.out', overwrite: 'auto' }))
    }
    el.addEventListener('pointermove', move)
    return () => el.removeEventListener('pointermove', move)
  }, [])

  return (
    <section id="top" ref={root} className="relative flex min-h-[100svh] items-end overflow-hidden px-5 pb-16 pt-28 md:px-10 md:pb-14">
      <div className="stage-wrap pointer-events-none absolute right-[-14%] top-[8%] h-[72vmin] w-[72vmin] md:right-[2%] md:top-[12%] md:h-[78vmin] md:w-[78vmin]" aria-hidden="true">
        <div className="stage relative h-full w-full">
          <div className="stage-tilt h-full w-full" style={{ transformStyle: 'preserve-3d' }}>
            <div ref={rig} className="rig relative h-full w-full">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="layer" style={{ transform: `translateZ(${(i - 2.5) * 54}px) rotate(${i * 15}deg)`, opacity: .35 + i * .12 }} />
              ))}
              <div className="absolute inset-[40%] rounded-[30%] bg-violet" style={{ transform: 'rotate(45deg)' }} />
            </div>
          </div>
        </div>
        {chips.map(([t, l, tp, d]) => (
          <span key={t} data-depth={d} className="chip absolute rounded-full border px-4 py-1.5 text-xs backdrop-blur-sm hairline muted" style={{ left: l, top: tp }}>{t}</span>
        ))}
      </div>

      <div className="h-content relative z-10 w-full">
        <h1 className="display text-[clamp(3.4rem,13.5vw,12rem)]">
          <Chars text="MUHAMMED" className="block" />
          <Chars text="YASEEN" className="block md:pl-[8vw]" />
        </h1>
        <p className="h-sub mt-8 text-base font-medium md:text-xl">Creative Designer • BCA Student • AI/ML Explorer</p>
        <p className="h-intro muted mt-4 max-w-md text-[15px] leading-relaxed">
          I design interfaces, brands and posters, and I’m learning how machines learn. Right now I’m building the skills to connect the two.
        </p>
        <div className="mt-9 flex flex-wrap gap-3">
          <button onClick={() => scrollToId('work')} className="h-btn rounded-full bg-violet px-7 py-3.5 text-sm font-semibold text-ink transition hover:bg-ivory">Explore My Work</button>
          <button onClick={() => scrollToId('contact')} className="h-btn hairline rounded-full border px-7 py-3.5 text-sm font-semibold transition hover:border-violet hover:text-violet">Contact Me</button>
        </div>
      </div>

      <div className="h-cue absolute bottom-6 right-5 hidden flex-col items-center gap-3 md:flex md:right-10" aria-hidden="true">
        <span className="muted text-xs [writing-mode:vertical-rl]">Scroll</span>
        <span className="cue relative h-14 w-px overflow-hidden bg-white/20" />
        <ArrowDown size={14} className="muted" />
      </div>
    </section>
  )
}
