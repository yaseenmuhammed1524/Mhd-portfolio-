import { useRef } from 'react'
import { gsap, useGsap } from '../lib/scroll'
import { Words } from './Split'

const statement = 'I’m a first-year BCA student drawn to creative design, technology and AI/ML. I like making things that look considered and work well, and I’m learning how to build them from both sides.'
const phrases = ['DESIGN', 'TECHNOLOGY', 'CREATIVITY', 'INNOVATION']

export default function About() {
  const root = useRef(null)
  useGsap(root, () => {
    // Global colour transition: charcoal to ivory while inside About, and back afterwards
    const to = (dark) => gsap.to(document.documentElement, {
      '--bg': dark ? '#161618' : '#f2efe8', '--fg': dark ? '#f2efe8' : '#161618',
      '--line': dark ? 'rgba(242,239,232,.14)' : 'rgba(22,22,24,.16)', '--mut': dark ? 'rgba(242,239,232,.62)' : 'rgba(22,22,24,.66)',
      '--acc': dark ? '#a78bfa' : '#6d48e8', duration: .9, ease: 'power2.inOut', overwrite: true })
    gsap.timeline({ scrollTrigger: { trigger: root.current, start: 'top 55%', end: 'bottom 45%',
      onEnter: () => to(false), onLeave: () => to(true), onEnterBack: () => to(false), onLeaveBack: () => to(true) } })

    // Pinned statement: words resolve from blur, portrait mask opens and settles
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: { trigger: '.pin', start: 'top top', end: '+=140%', pin: true, scrub: .6 } })
    tl.fromTo('.word', { opacity: .14, filter: 'blur(5px)' }, { opacity: 1, filter: 'blur(0px)', stagger: .12, duration: 1 }, 0)
      .fromTo('.portrait', { clipPath: 'inset(45% 45% 45% 45% round 200px)', rotate: -8, scale: .8 },
        { clipPath: 'inset(0% 0% 0% 0% round 28px)', rotate: 2, scale: 1, duration: 1.4 }, 0)
      .fromTo('.portrait-in', { scale: 1.6 }, { scale: 1, duration: 1.4 }, 0)
      .to('.about-bg', { yPercent: -30, duration: 1.4 }, 0)
    gsap.from('.fact', { y: 50, opacity: 0, stagger: .12, duration: 1, ease: 'expo.out', scrollTrigger: { trigger: '.facts', start: 'top 85%' } })
  })

  const row = [...phrases, ...phrases].map((p, i) => (
    <span key={i} className="display flex items-center gap-10 pr-10 text-[clamp(3rem,9vw,8rem)]">
      <span className={i % 2 ? 'text-transparent [-webkit-text-stroke:1.5px_var(--fg)]' : ''}>{p}</span><span className="text-[var(--acc)]">•</span>
    </span>
  ))

  return (
    <section id="about" ref={root} className="relative">
      <div className="pin relative flex min-h-screen items-center overflow-hidden px-5 py-24 md:px-10">
        <div className="about-bg display pointer-events-none absolute -left-10 top-1/2 select-none text-[28vw] font-bold leading-none opacity-[.05]" aria-hidden="true">BCA</div>
        <div className="relative grid w-full items-center gap-12 md:grid-cols-[1.35fr_1fr]">
          <h2 className="display text-[clamp(1.9rem,4.4vw,4.2rem)] !leading-[1.08] !tracking-[-.03em]"><Words text={statement} /></h2>
          <div className="portrait relative mx-auto aspect-[4/5] w-full max-w-sm overflow-hidden bg-ink">
            <div className="portrait-in absolute inset-0 grid place-items-center">
              <div className="absolute inset-0 opacity-60 [background:repeating-linear-gradient(135deg,transparent_0_22px,rgba(167,139,250,.14)_22px_23px)]" />
              <span className="display relative text-[9rem] text-violet">MY</span>
              <span className="absolute bottom-4 left-5 text-xs text-white/50">Portrait placeholder</span>
            </div>
          </div>
        </div>
      </div>

      <div className="overflow-hidden border-y py-6 hairline" aria-hidden="true">
        <div className="marquee-track flex">{row}{row}</div>
      </div>

      <div className="facts grid px-5 py-24 md:grid-cols-3 md:gap-8 md:px-10">
        {[['Studying', 'First-year BCA, building a base in programming and computing.'],
          ['Designing', 'Posters, brand identities and web interfaces, with a focus on clear hierarchy.'],
          ['Exploring', 'Machine learning fundamentals, one small experiment at a time.']].map(([t, d]) => (
          <div key={t} className="fact border-t py-8 hairline">
            <h3 className="display !leading-none text-3xl">{t}</h3>
            <p className="muted mt-4 max-w-xs leading-relaxed">{d}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
