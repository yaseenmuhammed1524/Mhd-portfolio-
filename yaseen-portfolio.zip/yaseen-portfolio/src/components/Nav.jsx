import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { scrollToId } from '../lib/scroll'

const links = [['about', 'About'], ['skills', 'Skills'], ['work', 'Work'], ['contact', 'Contact']]

export default function Nav() {
  const [open, setOpen] = useState(false)
  const go = (id) => { const was = open; setOpen(false); setTimeout(() => scrollToId(id), was ? 300 : 0) }
  return (
    <header className="fixed inset-x-0 top-0 z-50 text-white mix-blend-difference">
      <nav className="flex items-center justify-between px-5 py-5 md:px-10" aria-label="Primary">
        <button onClick={() => go('top')} className="display text-xl" aria-label="Back to top">MY</button>
        <ul className="hidden gap-9 text-sm md:flex">
          {links.map(([id, l]) => (
            <li key={id}><button onClick={() => go(id)} className="group relative py-1">{l}
              <span className="absolute inset-x-0 -bottom-0.5 h-px origin-left scale-x-0 bg-white transition-transform duration-500 group-hover:scale-x-100" /></button></li>
          ))}
        </ul>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label="Toggle menu">{open ? <X /> : <Menu />}</button>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.ul initial={{ clipPath: 'inset(0 0 100% 0)' }} animate={{ clipPath: 'inset(0 0 0% 0)' }} exit={{ clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: .5, ease: [.7, 0, .2, 1] }}
            className="fixed inset-0 -z-10 flex flex-col justify-center gap-6 bg-black px-8 md:hidden">
            {links.map(([id, l], i) => (
              <motion.li key={id} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: .15 + i * .07 }}>
                <button onClick={() => go(id)} className="display text-5xl">{l}</button></motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </header>
  )
}
